﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;

//namespace WRM.Models
//{
//    public class StaffEdit
//    {
//        public string Availability { get; set; }
//        public string PNRNo { get; set; }
//        public int GateNo { get; set; }
//    }
//}
