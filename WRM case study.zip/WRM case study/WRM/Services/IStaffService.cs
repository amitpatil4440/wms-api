﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WRM.Models;

namespace WRM.Services
{
    public interface IStaffService
    {
        
        List<Staff> GetAllStaff();
        Staff LogIn(LoginStaff loginStaff);
        List<Staff> StaffStatusAvailable();
        Task<string> AddStaff(Staff staff);
        Staff StaffUpdate(int staffId, Staff staff);
        Staff GetDetailsByEmail(string email);
        //Task<object> GetStaffByEmail(string email);
    }
}
