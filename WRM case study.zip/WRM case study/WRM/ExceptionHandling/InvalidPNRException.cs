﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WRM.ExceptionHandling
{
    public class InvalidPNRException: ApplicationException
    {
        public InvalidPNRException()
        {
        }
        public InvalidPNRException(string msg) : base(msg)
        {
        }
    }
}
