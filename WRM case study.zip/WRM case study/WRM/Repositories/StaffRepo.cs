﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WRM.Context;
using WRM.ExceptionHandling;
using WRM.Models;

namespace WRM.Repositories
{
    public class StaffRepo : IStaffRepo
    {
        readonly WrmDbContext _wrmDbContext;
        public StaffRepo(WrmDbContext wrmDbContext)
        {
            _wrmDbContext = wrmDbContext;
        }

        public int AddStaff(Staff staff)
        {
        
            _wrmDbContext.StaffTbl.Add(staff);
            return _wrmDbContext.SaveChanges();
        }
        public List<Staff> GetAllStaff()
        {
            List<Staff> staff = _wrmDbContext.StaffTbl.ToList();
            return staff;
        }

        public Staff GetDetailsByEmail(string email)
        {
            return _wrmDbContext.StaffTbl.Where(s => s.Email == email).FirstOrDefault();
        }

        public async Task<object> GetStaffByEmail(string Email)
        {
            return await _wrmDbContext.StaffTbl.Where(s => s.Email == Email).FirstOrDefaultAsync();
        }

        public Staff logIn(LoginStaff loginStaff)
        {
            
            Staff login = _wrmDbContext.StaffTbl.Where(s => s.Email == loginStaff.Email || s.Password == loginStaff.Password).FirstOrDefault();
            
            if (login != null)
            {
                if (login.Email == loginStaff.Email)
                {
                    return login;
                }
                else
                {
                    throw new StaffEmailInvalidException($"Invalid email");
                }
            }
            else
            {
                throw new StaffInvalidException($"Invalid Credentials");
            }
        }
        public List<Staff> StaffStatusAvailable()
        {
            List<Staff> staff = _wrmDbContext.StaffTbl.Where(s => s.Availability == "Available").ToList();
            return staff;
        }

        public Staff StaffUpdate(int staffId, Staff staff)
        {
            staff.StaffId = staffId;
            _wrmDbContext.Entry(staff).State = EntityState.Modified;
            _wrmDbContext.SaveChanges();
            return staff;
        }

        //object IStaffRepo.GetStaffByEmail(string email)
        //{
        //    //return _csdbContext.PTable.Where(p => p.ProductId == id).FirstOrDefault();
        //    return _wrmDbContext.StaffTbl.Where(s => s.Email == email).FirstOrDefault();
        //}
    }



       
    
}
