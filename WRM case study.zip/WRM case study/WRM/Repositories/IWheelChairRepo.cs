﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WRM.Models;

namespace WRM.Repositories
{
    public interface IWheelChairRepo
    {
        Task<WheelChair> GetWheelChairByWId(int wId);
        int addwheelChair(WheelChair wheelchair);
        WheelChair WheelChairUpdate(int wId, WheelChair wheelChair);
        List<WheelChair> GetAllWheelChairs();
    }
}
