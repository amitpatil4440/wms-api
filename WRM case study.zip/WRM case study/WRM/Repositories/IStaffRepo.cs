﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WRM.Models;

namespace WRM.Repositories
{
    public interface IStaffRepo
    {
        //Staff GetStaffByEmail(string email);
        
        List<Staff> GetAllStaff();
        Staff logIn(LoginStaff loginStaff);
        List<Staff> StaffStatusAvailable();
        int AddStaff(Staff staff);
        Staff StaffUpdate(int staffId, Staff staff);
        Task<object> GetStaffByEmail(string email);
        Staff GetDetailsByEmail(string email);
    }
}
